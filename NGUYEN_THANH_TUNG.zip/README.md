# CNTT17-15_JavaScriptWEB 
#BTL-> HTML, CSS, JAVASCRIPT, JQUERY, BOOTSTRAP
8/5/2024 
Tôi tạo ra BTL_JavsScript để  báo cáo môn  Js của trường tôi  yêu  cầu . 
Trong BTL tôi tập trung vào HTML + CSS + JAVSSCRIPT 
